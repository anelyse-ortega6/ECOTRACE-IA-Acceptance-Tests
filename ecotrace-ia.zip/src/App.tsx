import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Mail, 
  User, 
  CheckCircle2, 
  ShieldCheck, 
  Leaf, 
  Cpu, 
  FileText, 
  ChevronRight, 
  Sparkles, 
  Clock, 
  ArrowRight,
  TrendingDown,
  TrendingUp,
  Lock,
  Info,
  X,
  LayoutDashboard,
  Camera,
  Droplet,
  Zap,
  Trash2,
  Calendar,
  Send,
  Lightbulb,
  RefreshCw,
  MessageSquare,
  Menu,
  LogOut,
  Download,
  Award,
  FileCheck,
  Check,
  ChevronLeft,
  Landmark
} from 'lucide-react';
import { Transaction, ActionPlan } from './types';
import ReportModal from './components/ReportModal';

export default function App() {
  // Navigation & Screen States
  const [viewMode, setViewMode] = useState<'landing' | 'app'>('landing');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'ocr' | 'ai'>('dashboard');
  const [isReportOpen, setIsReportOpen] = useState(false);

  // Personalized Mype Profiles
  const [userName, setUserName] = useState('Julio Ramos');
  const [companyName, setCompanyName] = useState('Servicios Ramos Mype');
  const [email, setEmail] = useState('juliocesarramosmeza4@gmail.com');

  // Input states for Lead Form
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formCompany, setFormCompany] = useState('');

  // Core Simulation Metrics & Data
  const [carbonEmissions, setCarbonEmissions] = useState(450);
  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: 'tx-1',
      source: 'Grifo Sur S.A.',
      category: 'Combustible',
      date: '12/05',
      amount: 120.00,
      emissions: 36
    },
    {
      id: 'tx-2',
      source: 'Recibo Luz Enel',
      category: 'Electricidad',
      date: '10/05',
      amount: 250.00,
      emissions: 75
    }
  ]);

  // AI Recommendation Plans
  const [actionPlans, setActionPlans] = useState<ActionPlan[]>([
    {
      id: 'plan-1',
      title: 'Optimización de Rutas Logísticas',
      icon: 'route',
      description: 'Tus gastos subieron 15%. Agrupa las entregas de los viernes para disminuir el kilometraje inútil.',
      savingAmount: 200,
      savingEmissions: 50,
      status: 'pending'
    },
    {
      id: 'plan-2',
      title: 'Eficiencia Energética',
      icon: 'led',
      description: 'Cambia luminarias a tecnología LED de bajo consumo en el Almacén B para reducir el factor de carga.',
      savingAmount: 95,
      savingEmissions: 35,
      status: 'pending'
    }
  ]);

  // Toast Notification State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const triggerToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 5000);
  };

  // OCR Simulator States
  const [scanState, setScanState] = useState<'idle' | 'scanning' | 'scanned'>('idle');
  const [ocrRuc, setOcrRuc] = useState('20123456789');
  const [ocrAmount, setOcrAmount] = useState('150.00');
  const [ocrCategory, setOcrCategory] = useState<'Combustible' | 'Electricidad' | 'Agua' | 'Residuos'>('Combustible');

  // Chatbot Assistant Simulation
  const [chatPrompt, setChatPrompt] = useState('');
  const [chatReplies, setChatReplies] = useState<Array<{ sender: 'user' | 'ia'; text: string }>>([
    { 
      sender: 'ia', 
      text: '¡Hola! He analizado tus consumos reportados. Tu huella se encuentra estable pero podemos optimizar un 18% tus egresos.' 
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);

  // Quick prompt suggestions
  const suggestions = [
    '¿Cómo reduzco emisiones en logística?',
    'Planes para ahorrar luz en mi local',
    '¿Qué exige el MINAM para Mypes?'
  ];

  // Handle OCR Sim Scan
  const startScanning = () => {
    setScanState('scanning');
    const timer = setTimeout(() => {
      setScanState('scanned');
      triggerToast('¡Escaneo exitoso! Los datos se han cargado en el formulario de validación.');
    }, 2000);
  };

  // Save parsed OCR record to transactions
  const handleSaveOcr = (e: React.FormEvent) => {
    e.preventDefault();
    if (scanState !== 'scanned') return;

    const numericAmount = parseFloat(ocrAmount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      triggerToast('Por favor ingrese un monto válido.');
      return;
    }

    let supplier = 'Proveedor Detectado';
    let emissionFactor = 0.3; // Default factor

    if (ocrCategory === 'Combustible') {
      supplier = 'Grifo Repsol';
      emissionFactor = 0.3; // S/150 -> 45 kg
    } else if (ocrCategory === 'Electricidad') {
      supplier = 'Luz del Sur S.A.A.';
      emissionFactor = 0.25;
    } else if (ocrCategory === 'Agua') {
      supplier = 'Sedapal S.A.';
      emissionFactor = 0.12;
    } else {
      supplier = 'Disposición Muncipal';
      emissionFactor = 0.15;
    }

    const calculatedEmissions = Math.round(numericAmount * emissionFactor);

    const newTx: Transaction = {
      id: 'tx-' + Date.now(),
      source: supplier,
      category: ocrCategory,
      date: 'Hoy',
      amount: numericAmount,
      emissions: calculatedEmissions
    };

    setTransactions(prev => [newTx, ...prev]);
    setCarbonEmissions(prev => prev + calculatedEmissions);
    setScanState('idle');
    triggerToast(`¡Registro Guardado! Se agregaron +${calculatedEmissions} kg CO₂ al panel de ${companyName}.`);
    
    // Automatically switch back to Dashboard to see the new record
    setTimeout(() => {
      setActiveTab('dashboard');
    }, 500);
  };

  // Handle AI Plan Application
  const handleApplyPlan = (planId: string, savingEmissions: number) => {
    setActionPlans(prev => prev.map(p => {
      if (p.id === planId) {
        return { ...p, status: 'applied' };
      }
      return p;
    }));
    setCarbonEmissions(prev => Math.max(0, prev - savingEmissions));
    triggerToast(`¡Estrategia aplicada con éxito! Redujiste -${savingEmissions} kg CO₂ de tu huella ambiental.`);
  };

  const handleIgnorePlan = (planId: string) => {
    setActionPlans(prev => prev.map(p => {
      if (p.id === planId) {
        return { ...p, status: 'ignored' };
      }
      return p;
    }));
    triggerToast('Recomendación archivada.');
  };

  const handleResetPlans = () => {
    setActionPlans(prev => prev.map(p => ({ ...p, status: 'pending' })));
    setCarbonEmissions(450 + transactions.slice(2).reduce((sum, t) => sum + t.emissions, 0));
    triggerToast('Se han restablecido todos los planes de acción del Consultor.');
  };

  // Send message to chatbot
  const sendMessage = (text: string) => {
    if (!text.trim()) return;

    const newMessages = [...chatReplies, { sender: 'user', text }];
    setChatReplies(newMessages);
    setChatPrompt('');
    setIsTyping(true);

    setTimeout(() => {
      let replyText = 'Entendido. Según tu perfil de Mype, implementar un día de teletrabajo o apagar servidores por las noches disminuirá tus gastos en un 8%.';
      
      const query = text.toLowerCase();
      if (query.includes('logística') || query.includes('combustible') || query.includes('ruta')) {
        replyText = 'Para mitigar el gasto de combustible en logística, aconsejo agrupar entregas por sectores geográficos los viernes. Lograrás S/ 200 de ahorro y reducirás 50 kg de CO₂.';
      } else if (query.includes('luz') || query.includes('iluminación') || query.includes('led')) {
        replyText = 'Cambiando las luminarias a tecnología LED de 15W en tus bodegas o almacenes ahorrarás hasta S/ 95 mensuales, con un retorno de inversión de 3 meses.';
      } else if (query.includes('minam') || query.includes('exige') || query.includes('reporte')) {
        replyText = 'El Ministerio del Ambiente (MINAM) promueve el sello "Huella de Carbono Perú" para Mypes. Al certificar tu huella con EcoTrace, ganas ventajas competitivas para contrataciones del Estado.';
      }

      setChatReplies(prev => [...prev, { sender: 'ia', text: replyText }]);
      setIsTyping(false);
    }, 1200);
  };

  // Handle lead capture form
  const handleLeadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formCompany.trim() || !formEmail.trim()) {
      triggerToast('Por favor, completa todos los campos del formulario.');
      return;
    }

    setUserName(formName);
    setCompanyName(formCompany);
    setEmail(formEmail);
    setViewMode('app');
    setActiveTab('dashboard');
    triggerToast(`¡Bienvenido ${formName}! Simulador personalizado para "${formCompany}"`);
  };

  // Direct login toggle (without form)
  const handleDirectLogin = () => {
    setViewMode('app');
    setActiveTab('dashboard');
    triggerToast('Acceso directo al simulador interactivo.');
  };

  // Spend total calculator
  const totalSpent = transactions.reduce((sum, t) => sum + t.amount, 0);

  // Chart configuration for Ene-Abr
  const chartMonths = [
    { name: 'Ene', value: 240, color: 'bg-emerald-200' },
    { name: 'Feb', value: 380, color: 'bg-emerald-300' },
    { name: 'Mar', value: 310, color: 'bg-emerald-400' },
    { name: 'Abr', value: carbonEmissions, color: 'bg-emerald-500 shadow-md shadow-emerald-500/20' }
  ];
  const maxEmissionsVal = Math.max(...chartMonths.map(m => m.value));

  // Category visual helper
  const getCategoryTheme = (category: string) => {
    switch (category) {
      case 'Combustible':
        return { bg: 'bg-amber-50 border-amber-100', text: 'text-amber-700', icon: '🔥' };
      case 'Electricidad':
        return { bg: 'bg-emerald-50 border-emerald-100', text: 'text-emerald-700', icon: '⚡' };
      case 'Agua':
        return { bg: 'bg-blue-50 border-blue-100', text: 'text-blue-700', icon: '💧' };
      case 'Residuos':
        return { bg: 'bg-slate-50 border-slate-100', text: 'text-slate-700', icon: '♻️' };
      default:
        return { bg: 'bg-slate-50 border-slate-100', text: 'text-slate-700', icon: '📝' };
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#1E293B] font-sans flex flex-col selection:bg-emerald-500/10 selection:text-emerald-800">
      
      {/* FLOAT TOAST NOTIFICATION */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white rounded-2xl px-5 py-3.5 shadow-2xl border border-slate-800 max-w-sm flex items-start space-x-3 animate-slide-in">
          <div className="p-1 rounded-full bg-emerald-500/15 text-emerald-400 shrink-0 mt-0.5">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <p className="text-xs font-bold text-white">Alerta del Sistema</p>
            <p className="text-[11px] text-slate-300 mt-0.5 leading-normal">{toastMessage}</p>
          </div>
          <button onClick={() => setToastMessage(null)} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* VIEW STATE 1: LANDING PAGE */}
      {viewMode === 'landing' && (
        <div className="flex-1 flex flex-col">
          {/* HEADER */}
          <header className="sticky top-0 bg-white/80 backdrop-blur-md border-b border-slate-100 z-40 transition-all">
            <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
              
              {/* Logo */}
              <div className="flex items-center space-x-3">
                <img 
                  src="https://i.postimg.cc/y6Tv4Cz3/logo-Eco-Trace1.png" 
                  alt="EcoTrace IA Logo" 
                  className="h-10 object-contain"
                />
                <span className="font-extrabold text-lg text-emerald-600 tracking-tight">EcoTrace IA</span>
              </div>

              {/* Navigation Links (Commercial) */}
              <nav className="hidden md:flex items-center space-x-8 text-sm font-semibold text-slate-600">
                <a href="#beneficios" className="hover:text-emerald-600 transition-colors">Beneficios</a>
                <a href="#tecnologia" className="hover:text-emerald-600 transition-colors">Tecnología OCR</a>
                <a href="#consultor" className="hover:text-emerald-600 transition-colors">Consultor Inteligente</a>
              </nav>

              {/* Action Buttons */}
              <div className="flex items-center space-x-4">
                <button 
                  onClick={handleDirectLogin}
                  className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs transition-all shadow-md shadow-emerald-500/10 active:scale-95"
                >
                  Iniciar Sesión
                </button>
              </div>
            </div>
          </header>

          {/* HERO SECTION */}
          <section className="py-16 md:py-24 px-6 max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left commercial content */}
            <div className="lg:col-span-7 space-y-6 text-left">
              <div className="inline-flex items-center space-x-2 bg-emerald-50 border border-emerald-100 px-3.5 py-1.5 rounded-full">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-[11px] font-bold text-emerald-800 tracking-wide uppercase">Plataforma Oficial MYPE</span>
              </div>

              <h1 className="text-4xl md:text-5xl font-black text-slate-900 leading-tight tracking-tight">
                Automatiza tu Huella de Carbono y <span className="text-emerald-500">Ahorra Dinero</span> con IA
              </h1>

              <p className="text-slate-600 text-sm md:text-base max-w-2xl leading-relaxed">
                Diseñado exclusivamente para micro y pequeñas empresas (Mype) en el Perú. Digitaliza facturas de luz, agua y combustible instantáneamente mediante nuestro escáner con OCR inteligente. Genera reportes automáticos certificados listos para el Ministerio del Ambiente (MINAM) y recibe sugerencias personalizadas para recortar costos operacionales.
              </p>

              {/* Hero Image Block */}
              <div className="relative group overflow-hidden rounded-2xl shadow-xl border border-slate-100 bg-white p-2">
                <img 
                  src="https://i.postimg.cc/NGxpqvwH/imagenv1.png" 
                  alt="EcoTrace Platform Demo" 
                  className="w-full rounded-xl object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/20 to-transparent pointer-events-none"></div>
              </div>
            </div>

            {/* Right lead capture form */}
            <div className="lg:col-span-5 bg-white p-8 rounded-3xl border border-slate-100 shadow-xl space-y-6">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto shadow-sm">
                  <Leaf className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-extrabold text-slate-900 tracking-tight">Regístrate y Prueba el Simulador</h3>
                <p className="text-xs text-slate-500">
                  Accede gratis al prototipo interactivo adaptado a tu negocio.
                </p>
              </div>

              <form onSubmit={handleLeadSubmit} className="space-y-4 text-left">
                {/* Full name */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Tu Nombre y Apellido</label>
                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder="Ej. Julio Ramos" 
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      required
                      className="w-full text-xs px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-emerald-500 focus:outline-none transition-all pl-10"
                    />
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  </div>
                </div>

                {/* Corporate email */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Correo Electrónico</label>
                  <div className="relative">
                    <input 
                      type="email" 
                      placeholder="Ej. julio@empresa.com" 
                      value={formEmail}
                      onChange={(e) => setFormEmail(e.target.value)}
                      required
                      className="w-full text-xs px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-emerald-500 focus:outline-none transition-all pl-10"
                    />
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  </div>
                </div>

                {/* Company name */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Razón Social / Mype</label>
                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder="Ej. Ramos Logística Mype" 
                      value={formCompany}
                      onChange={(e) => setFormCompany(e.target.value)}
                      required
                      className="w-full text-xs px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-emerald-500 focus:outline-none transition-all pl-10"
                    />
                    <Building2 className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  </div>
                </div>

                <div className="pt-2">
                  <button 
                    type="submit"
                    className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs transition-all shadow-md shadow-emerald-500/10 hover:shadow-emerald-500/20 flex items-center justify-center space-x-2"
                  >
                    <span>Comenzar gratis</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400 font-semibold">
                <span className="flex items-center space-x-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Datos Seguros</span>
                </span>
                <span>Prototipo 100% Funcional</span>
              </div>
            </div>
          </section>

          {/* BENEFICIOS / COMMERCIAL LAYOUT */}
          <section id="beneficios" className="bg-white py-16 border-t border-slate-100">
            <div className="max-w-7xl mx-auto px-6">
              <div className="text-center space-y-3 max-w-2xl mx-auto mb-12">
                <h2 className="text-2xl font-extrabold text-slate-900">¿Por qué las Mypes eligen EcoTrace?</h2>
                <p className="text-sm text-slate-500">
                  Despídete de complejas hojas de cálculo de Excel. Automatizamos tu impacto ambiental en 3 pasos simples.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* benefit 1 */}
                <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100 space-y-4 text-left">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shadow-sm">
                    <Camera className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-slate-900 text-sm">Escáner OCR Inteligente</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Sube fotos de tus comprobantes de energía. EcoTrace extrae el RUC del emisor, montos y calcula automáticamente el CO₂ emitido sin ingresos manuales erróneos.
                  </p>
                </div>

                {/* benefit 2 */}
                <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100 space-y-4 text-left">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shadow-sm">
                    <Cpu className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-slate-900 text-sm">Consultor IA de Ahorros</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Un asesor artificial examina tus gastos mensuales para recomendarte acciones operativas concretas que reducen tus costos financieros y tu impacto ambiental simultáneamente.
                  </p>
                </div>

                {/* benefit 3 */}
                <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100 space-y-4 text-left">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shadow-sm">
                    <FileText className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-slate-900 text-sm">Reportes Oficiales MINAM</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Genera de inmediato el reporte de huella certificado bajo la normativa del Ministerio del Ambiente de Perú, ideal para licitaciones ecológicas públicas.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* FOOTER */}
          <footer className="bg-slate-900 text-slate-400 py-12 px-6 border-t border-slate-800 text-xs">
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center space-x-3">
                <img 
                  src="https://i.postimg.cc/y6Tv4Cz3/logo-Eco-Trace1.png" 
                  alt="EcoTrace Logo" 
                  className="h-8 object-contain"
                />
                <span className="font-bold text-white text-sm">EcoTrace IA</span>
              </div>
              <p>© 2026 EcoTrace IA. Todos los derechos reservados. Diseñado para la sostenibilidad de las Mypes de Perú.</p>
              <div className="flex space-x-4">
                <span className="text-emerald-500 font-semibold cursor-pointer" onClick={handleDirectLogin}>Probar Prototipo</span>
              </div>
            </div>
          </footer>
        </div>
      )}

      {/* VIEW STATE 2: INTERACTIVE SIMULATOR (FULL SCREEN) */}
      {viewMode === 'app' && (
        <div className="flex-1 flex flex-col md:flex-row min-h-screen bg-[#F8FAFC]">
          
          {/* SIDEBAR NAVIGATION */}
          <aside className="w-full md:w-64 bg-white border-b md:border-b-0 md:border-r border-slate-100 flex flex-col justify-between shrink-0">
            <div>
              {/* Sidebar Header with Logo */}
              <div className="p-6 border-b border-slate-50 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <img 
                    src="https://i.postimg.cc/y6Tv4Cz3/logo-Eco-Trace1.png" 
                    alt="EcoTrace" 
                    className="h-8 object-contain"
                  />
                  <span className="font-extrabold text-sm text-emerald-600 tracking-tight">EcoTrace IA</span>
                </div>
                <div className="md:hidden">
                  <button 
                    onClick={() => setViewMode('landing')}
                    className="p-1.5 rounded-lg hover:bg-slate-50 text-slate-500"
                    title="Volver a Landing"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* User Profile Summary Inside Sidebar */}
              <div className="p-4 mx-4 my-4 bg-emerald-50/40 rounded-2xl border border-emerald-100/45 text-left">
                <div className="flex items-center space-x-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500 flex items-center justify-center text-slate-950 font-black text-xs shadow-sm shrink-0">
                    {userName.charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <p className="text-[11px] font-bold text-slate-900 truncate leading-tight">{userName}</p>
                    <p className="text-[10px] text-slate-500 truncate mt-0.5">{companyName}</p>
                  </div>
                </div>
              </div>

              {/* Sidebar Menu Items */}
              <nav className="px-3 space-y-1">
                {/* Tab 1: Dashboard */}
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'dashboard'
                      ? 'bg-emerald-50 text-emerald-700'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <LayoutDashboard className="w-4 h-4 shrink-0" />
                  <span>Dashboard de Emisiones</span>
                </button>

                {/* Tab 2: OCR Scanner */}
                <button
                  onClick={() => setActiveTab('ocr')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'ocr'
                      ? 'bg-emerald-50 text-emerald-700'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Camera className="w-4 h-4 shrink-0" />
                  <span>Escáner OCR Facturas</span>
                </button>

                {/* Tab 3: Consultor IA */}
                <button
                  onClick={() => setActiveTab('ai')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'ai'
                      ? 'bg-emerald-50 text-emerald-700'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Cpu className="w-4 h-4 shrink-0" />
                  <span>Consultor IA Sostenible</span>
                </button>
              </nav>
            </div>

            {/* Sidebar Bottom Actions */}
            <div className="p-4 border-t border-slate-50 space-y-2">
              <div className="bg-slate-50 rounded-xl p-3 text-[10px] text-slate-500 leading-relaxed text-left border border-slate-100">
                <span className="font-bold text-slate-700 block mb-0.5">💡 Tip Operativo:</span>
                Prueba escanear un recibo de combustible en la pestaña de OCR para ver cómo impacta el Dashboard.
              </div>

              <button
                onClick={() => {
                  setViewMode('landing');
                  triggerToast('Cierre de sesión simulado. Volviste a la Landing Page.');
                }}
                className="w-full flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold text-slate-500 hover:bg-red-50 hover:text-red-600 transition-all border border-transparent hover:border-red-100"
              >
                <LogOut className="w-4 h-4" />
                <span>Cerrar Sesión</span>
              </button>
            </div>
          </aside>

          {/* MAIN CONTENT WORKSPACE */}
          <main className="flex-1 flex flex-col overflow-y-auto max-h-screen">
            
            {/* TAB CONTENT A: DASHBOARD DE EMISIONES */}
            {activeTab === 'dashboard' && (
              <div className="p-6 md:p-8 space-y-6 text-left animate-fade-in">
                
                {/* Header Row */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-5">
                  <div>
                    <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider block">Panel de Control</span>
                    <h2 className="text-xl md:text-2xl font-black text-slate-900">Panel de Control Ambiental</h2>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <span className="text-xs text-slate-500 font-mono font-bold bg-slate-100 px-3 py-1.5 rounded-full border border-slate-200">
                      MYPE: {companyName}
                    </span>
                    <button
                      onClick={() => setIsReportOpen(true)}
                      className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all flex items-center space-x-2"
                    >
                      <FileText className="w-4 h-4" />
                      <span>Exportar Reporte MINAM (PDF)</span>
                    </button>
                  </div>
                </div>

                {/* Metrics Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Metric 1 */}
                  <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden flex flex-col justify-between min-h-[140px]">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Total Huella de Carbono</span>
                      <p className="text-3xl font-extrabold text-emerald-500">
                        {carbonEmissions} <span className="text-xs font-bold text-slate-400">kg CO₂eq</span>
                      </p>
                    </div>
                    <div className="pt-2 border-t border-slate-50 flex items-center justify-between text-[10px] text-slate-400 font-semibold">
                      <span className="flex items-center space-x-1">
                        <TrendingDown className="w-3.5 h-3.5 text-emerald-500" />
                        <span className="text-emerald-600">Disminuyó -15% esta semana</span>
                      </span>
                    </div>
                  </div>

                  {/* Metric 2 */}
                  <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden flex flex-col justify-between min-h-[140px]">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Gastos Operativos Registrados</span>
                      <p className="text-3xl font-extrabold text-slate-800">
                        S/ {totalSpent.toFixed(2)} <span className="text-xs font-bold text-slate-400">PEN</span>
                      </p>
                    </div>
                    <div className="pt-2 border-t border-slate-50 flex items-center justify-between text-[10px] text-slate-500">
                      <span>Total de {transactions.length} facturas validadas</span>
                    </div>
                  </div>

                  {/* Metric 3 */}
                  <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden flex flex-col justify-between min-h-[140px]">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Estado de Sostenibilidad</span>
                      <p className="text-lg font-black text-slate-800 flex items-center space-x-2 mt-1">
                        <Award className="w-5 h-5 text-emerald-500 shrink-0 animate-bounce" />
                        <span>Sello Nivel 1 (MINAM)</span>
                      </p>
                    </div>
                    <div className="pt-2 border-t border-slate-50 flex items-center justify-between text-[10.5px] text-emerald-600 font-semibold">
                      <span>Prototipo listo para certificar</span>
                    </div>
                  </div>
                </div>

                {/* Chart and Table Section */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  
                  {/* Left Column: Bar Chart */}
                  <div className="lg:col-span-6 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-xs font-bold text-slate-900">Histórico de Emisiones Mensuales</h4>
                        <p className="text-[10px] text-slate-400 mt-0.5">Proyección para el presente año</p>
                      </div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase">Métrica: kg CO₂eq</span>
                    </div>

                    {/* Chart Container */}
                    <div className="flex items-end justify-between px-4 pt-6 border-b border-slate-100 h-44">
                      {chartMonths.map((m, idx) => {
                        const pct = maxEmissionsVal > 0 ? (m.value / maxEmissionsVal) * 100 : 0;
                        return (
                          <div key={idx} className="flex flex-col items-center flex-1 group">
                            {/* Contenedor de barra con altura fija para que el porcentaje funcione correctamente */}
                            <div className="h-28 w-full flex items-end justify-center relative">
                              {/* Indicador flotante en hover con buen contraste */}
                              <span className="absolute -top-7 text-[10px] font-bold text-slate-700 bg-slate-50 border border-slate-200 px-2 py-0.5 rounded shadow-md opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none z-10 whitespace-nowrap">
                                {m.value} kg CO₂
                              </span>
                              
                              {/* Barra de emisión con colores bien contrastados */}
                              <div 
                                style={{ height: `${Math.max(pct, 10)}%` }}
                                className={`w-10 sm:w-12 rounded-t-lg ${m.color} transition-all duration-500 ease-out hover:brightness-95`}
                              ></div>
                            </div>
                            
                            {/* Nombre del mes */}
                            <span className="text-[11px] font-bold text-slate-500 mt-2 pb-2">{m.name}</span>
                          </div>
                        );
                      })}
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-400 pt-1 font-semibold">
                      <span>Enero - Abril 2026</span>
                      <span className="text-emerald-600 flex items-center space-x-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                        <span>Abril incluye datos dinámicos</span>
                      </span>
                    </div>
                  </div>

                  {/* Right Column: Transactions List */}
                  <div className="lg:col-span-6 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-xs font-bold text-slate-900 font-sans">Últimos consumos registrados</h4>
                        <p className="text-[10px] text-slate-400 mt-0.5">Ingresados manualmente o por escaneo OCR</p>
                      </div>
                      <button 
                        onClick={() => setActiveTab('ocr')}
                        className="text-[10px] text-emerald-600 font-bold hover:underline"
                      >
                        + Escanear Factura
                      </button>
                    </div>

                    <div className="divide-y divide-slate-50 max-h-[220px] overflow-y-auto pr-2">
                      {transactions.map((tx) => {
                        const theme = getCategoryTheme(tx.category);
                        return (
                          <div key={tx.id} className="py-3 flex items-center justify-between hover:bg-slate-50/50 transition-colors rounded-lg px-2 -mx-2">
                            <div className="flex items-center space-x-3">
                              <span className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm border ${theme.bg}`}>
                                {theme.icon}
                              </span>
                              <div>
                                <span className="text-xs font-bold text-slate-800 block leading-none">{tx.source}</span>
                                <span className="text-[10px] text-slate-400 flex items-center space-x-1.5 mt-1">
                                  <span>{tx.date}</span>
                                  <span>•</span>
                                  <span className={`font-semibold ${theme.text}`}>{tx.category}</span>
                                </span>
                              </div>
                            </div>
                            <div className="text-right">
                              <span className="text-xs font-bold text-slate-800 block">S/ {tx.amount.toFixed(2)}</span>
                              <span className="text-[9.5px] font-bold text-emerald-600 bg-emerald-50 border border-emerald-100/50 rounded px-1.5 py-0.2 block mt-1">
                                +{tx.emissions} kg CO₂
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                </div>

              </div>
            )}

            {/* TAB CONTENT B: ESCÁNER OCR */}
            {activeTab === 'ocr' && (
              <div className="p-6 md:p-8 space-y-6 text-left animate-fade-in">
                
                {/* Header Row */}
                <div className="border-b border-slate-100 pb-5">
                  <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider block">Digitalización con IA</span>
                  <h2 className="text-xl md:text-2xl font-black text-slate-900">Digitalización de Facturas</h2>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  
                  {/* Left Column: Interactive Simulated Scanner */}
                  <div className="lg:col-span-5 bg-slate-900 rounded-3xl overflow-hidden shadow-xl border border-slate-800 flex flex-col">
                    
                    <div className="p-4 bg-slate-950 flex items-center justify-between text-white">
                      <div className="flex items-center space-x-2">
                        <Camera className="w-4 h-4 text-emerald-400" />
                        <span className="text-xs font-bold">Cámara de Escáner EcoTrace</span>
                      </div>
                      <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-full border border-emerald-800/60">IA READY</span>
                    </div>

                    <div className="relative h-64 bg-black flex flex-col items-center justify-center p-6 text-center">
                      {scanState === 'idle' && (
                        <div className="space-y-4 flex flex-col items-center">
                          <div className="w-16 h-16 rounded-full bg-slate-800/80 border-2 border-dashed border-emerald-500/40 flex items-center justify-center animate-pulse-ring">
                            <Camera className="w-7 h-7 text-emerald-400" />
                          </div>
                          <div>
                            <p className="text-xs text-slate-200 font-bold">Lente de Cámara Inteligente Listo</p>
                            <p className="text-[10px] text-slate-500 max-w-[240px] mt-1 mx-auto leading-normal">
                              Haz click abajo para simular la captura de tu comprobante de compra o recibo con la cámara de tu smartphone.
                            </p>
                          </div>
                          <button
                            onClick={startScanning}
                            className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-emerald-500/10 transition-all active:scale-95 cursor-pointer"
                          >
                            Capturar Factura Repsol
                          </button>
                        </div>
                      )}

                      {scanState === 'scanning' && (
                        <div className="w-full max-w-[280px] rounded-xl overflow-hidden border border-emerald-500/40 bg-slate-950 p-4 relative flex flex-col justify-between h-full">
                          <div className="absolute top-2 left-2 w-3.5 h-3.5 border-t-2 border-l-2 border-emerald-400"></div>
                          <div className="absolute top-2 right-2 w-3.5 h-3.5 border-t-2 border-r-2 border-emerald-400"></div>
                          <div className="absolute bottom-2 left-2 w-3.5 h-3.5 border-b-2 border-l-2 border-emerald-400"></div>
                          <div className="absolute bottom-2 right-2 w-3.5 h-3.5 border-b-2 border-r-2 border-emerald-400"></div>

                          {/* Simulating Laser Scanning Animation */}
                          <div className="absolute left-0 right-0 h-0.5 bg-emerald-400 shadow-[0_0_12px_rgba(16,185,129,0.8)] animate-scan-laser"></div>

                          {/* Mock Receipt text rendering */}
                          <div className="text-left font-mono text-[9px] text-slate-400 space-y-0.5 opacity-40 select-none pt-2">
                            <p className="text-center font-bold text-emerald-400">REPSOL COMBUSTIBLES PERÚ</p>
                            <p className="text-center">RUC: 20123456789</p>
                            <p>FECHA: 28/06/2026</p>
                            <p className="border-t border-dashed border-slate-700 my-1"></p>
                            <p>GL   PRODUCTO        TOTAL</p>
                            <p>8.2G DIESEL PREMIUM   S/ 150.00</p>
                            <p className="border-b border-dashed border-slate-700 my-1"></p>
                            <p className="text-right font-bold text-white">TOTAL PEN: S/ 150.00</p>
                          </div>

                          <div className="bg-slate-900/90 text-[10px] text-emerald-400 font-bold py-1 px-3 rounded-lg border border-emerald-500/20 inline-flex items-center justify-center space-x-2 mx-auto shadow-sm">
                            <RefreshCw className="w-3 h-3 animate-spin" />
                            <span>Procesando algoritmo OCR...</span>
                          </div>
                        </div>
                      )}

                      {scanState === 'scanned' && (
                        <div className="w-full max-w-[280px] rounded-xl overflow-hidden border border-emerald-500 bg-slate-950 p-4 relative flex flex-col justify-between h-full animate-fade-in">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
                            <span className="text-[9px] font-bold text-emerald-400 uppercase font-mono">Lectura Completa</span>
                            <span className="text-[9px] text-slate-400">Precisión 99.4%</span>
                          </div>

                          <div className="flex items-center space-x-3 my-auto">
                            <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                              <CheckCircle2 className="w-6 h-6 animate-pulse" />
                            </div>
                            <div className="text-left min-w-0">
                              <p className="text-xs font-bold text-white truncate">Factura Combustible</p>
                              <p className="text-[10px] text-slate-400 mt-0.5">Monto Extraído: S/ 150.00</p>
                              <p className="text-[9px] text-slate-500">RUC Emisor: 20123456789</p>
                            </div>
                          </div>

                          <button
                            onClick={startScanning}
                            className="text-[9px] text-slate-400 hover:text-emerald-400 font-bold transition-all mt-2 block mx-auto flex items-center space-x-1"
                          >
                            <RefreshCw className="w-2.5 h-2.5" />
                            <span>Escanear comprobante alternativo</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Right Column: Validation form */}
                  <div className="lg:col-span-7 bg-white p-6 md:p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
                    <div>
                      <h3 className="text-base font-bold text-slate-900">Validación de Datos Extraídos</h3>
                      <p className="text-xs text-slate-500 mt-1">
                        Verifica que los datos leídos por la inteligencia artificial de EcoTrace coincidan exactamente con tu comprobante físico antes de registrar la emisión.
                      </p>
                    </div>

                    <form onSubmit={handleSaveOcr} className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {/* RUC Input */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">RUC Emisor</label>
                          <div className="relative">
                            <input 
                              type="text"
                              value={ocrRuc}
                              onChange={(e) => setOcrRuc(e.target.value)}
                              disabled={scanState !== 'scanned'}
                              required
                              className={`w-full text-xs font-mono px-4 py-3 rounded-xl border focus:outline-none transition-all ${
                                scanState !== 'scanned'
                                  ? 'bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed'
                                  : 'border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10'
                              }`}
                            />
                            <Landmark className="w-4 h-4 text-slate-300 absolute right-3.5 top-3.5" />
                          </div>
                        </div>

                        {/* Category Select */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Categoría de Emisión</label>
                          <select
                            value={ocrCategory}
                            onChange={(e) => setOcrCategory(e.target.value as any)}
                            disabled={scanState !== 'scanned'}
                            className={`w-full text-xs px-4 py-3 rounded-xl border focus:outline-none transition-all ${
                              scanState !== 'scanned'
                                ? 'bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed'
                                : 'border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10'
                            }`}
                          >
                            <option value="Combustible">🔥 Combustible (Gasolina/Diesel)</option>
                            <option value="Electricidad">⚡ Electricidad (KWh)</option>
                            <option value="Agua">💧 Consumo de Agua (m³)</option>
                            <option value="Residuos">♻️ Generación de Residuos</option>
                          </select>
                        </div>

                        {/* Amount Input */}
                        <div className="space-y-1 sm:col-span-2">
                          <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Monto Total del Pago (S/)</label>
                          <div className="relative">
                            <span className="absolute left-4 top-3 text-xs text-slate-400 font-bold">S/</span>
                            <input 
                              type="text"
                              value={ocrAmount}
                              onChange={(e) => setOcrAmount(e.target.value)}
                              disabled={scanState !== 'scanned'}
                              required
                              placeholder="0.00"
                              className={`w-full text-xs font-bold px-9 py-3 rounded-xl border focus:outline-none transition-all ${
                                scanState !== 'scanned'
                                  ? 'bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed'
                                  : 'border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10'
                              }`}
                            />
                            <span className="text-[10px] font-bold text-slate-400 absolute right-4 top-3.5">PEN</span>
                          </div>
                        </div>
                      </div>

                      <div className="pt-4 border-t border-slate-50">
                        <button
                          type="submit"
                          disabled={scanState !== 'scanned'}
                          className={`w-full py-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all shadow-md ${
                            scanState === 'scanned'
                              ? 'bg-emerald-500 hover:bg-emerald-400 hover:shadow-emerald-500/10 text-slate-950 active:scale-98 cursor-pointer'
                              : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                          }`}
                        >
                          <Check className="w-4 h-4" />
                          <span>Validar y Guardar Registro</span>
                        </button>

                        {scanState !== 'scanned' && (
                          <div className="p-3 bg-amber-50 border border-amber-100 rounded-xl mt-4 text-[10px] text-amber-700 leading-normal flex items-start space-x-2">
                            <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                            <span>
                              <strong>Simulador Interactivo:</strong> Haz click primero en el botón verde <strong className="font-extrabold text-amber-800">"Capturar Factura Repsol"</strong> del recuadro izquierdo de la cámara para habilitar y autocompletar este formulario.
                            </span>
                          </div>
                        )}
                      </div>
                    </form>
                  </div>

                </div>

              </div>
            )}

            {/* TAB CONTENT C: CONSULTOR IA */}
            {activeTab === 'ai' && (
              <div className="p-6 md:p-8 space-y-6 text-left animate-fade-in">
                
                {/* Header Row */}
                <div className="border-b border-slate-100 pb-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider block">Sugerencias Inteligentes</span>
                    <h2 className="text-xl md:text-2xl font-black text-slate-900">Asesor de Inteligencia Artificial</h2>
                  </div>
                  
                  <button 
                    onClick={handleResetPlans}
                    className="self-start sm:self-auto text-[10px] font-bold text-slate-500 hover:text-emerald-600 bg-white border border-slate-200 px-3 py-1.5 rounded-xl hover:bg-slate-50 transition-all flex items-center space-x-1.5 shadow-xs"
                    title="Restablecer simulador"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Reiniciar Estados</span>
                  </button>
                </div>

                {/* Banner Status */}
                <div className="bg-emerald-50/50 border border-emerald-100 p-5 rounded-2xl flex items-start space-x-3.5 shadow-xs">
                  <div className="w-10 h-10 bg-emerald-500 text-slate-950 rounded-xl flex items-center justify-center shrink-0 shadow-sm">
                    <Sparkles className="w-5 h-5 animate-pulse" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-emerald-950">¡Análisis mensual completado con éxito!</p>
                    <p className="text-[11px] text-emerald-800 mt-1 leading-relaxed">
                      EcoTrace ha identificado 2 áreas críticas de optimización para <strong className="font-extrabold">{companyName}</strong>. Aquí tienes tus planes de optimización diseñados a la medida:
                    </p>
                  </div>
                </div>

                {/* Grid Layout: Left is Action Cards, Right is Chat Assistant */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  
                  {/* Action plans Column */}
                  <div className="lg:col-span-7 space-y-4">
                    <div className="flex items-center justify-between px-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Estrategias Recomendadas</span>
                      <span className="text-[10px] text-slate-500">{actionPlans.filter(p => p.status === 'applied').length} de {actionPlans.length} implementadas</span>
                    </div>

                    {actionPlans.map((plan) => {
                      const isApplied = plan.status === 'applied';
                      const isIgnored = plan.status === 'ignored';

                      return (
                        <div 
                          key={plan.id}
                          className={`p-5 rounded-2xl border transition-all duration-300 text-left ${
                            isApplied 
                              ? 'bg-emerald-50/20 border-emerald-200 opacity-90 shadow-xs' 
                              : isIgnored 
                              ? 'bg-slate-50 border-slate-200 opacity-60' 
                              : 'bg-white border-slate-100 shadow-sm hover:shadow-md'
                          }`}
                        >
                          <div className="flex items-start space-x-4">
                            {/* Card Category Badge */}
                            <div className={`p-2.5 rounded-xl shrink-0 ${
                              isApplied 
                                ? 'bg-emerald-100 text-emerald-700' 
                                : isIgnored 
                                ? 'bg-slate-200 text-slate-500' 
                                : 'bg-amber-50 text-amber-600 border border-amber-100'
                            }`}>
                              {plan.icon === 'route' ? (
                                <TrendingDown className="w-5 h-5" />
                              ) : (
                                <Lightbulb className="w-5 h-5" />
                              )}
                            </div>

                            <div className="flex-1 min-w-0 space-y-2">
                              <div className="flex items-center justify-between">
                                <h4 className="text-sm font-extrabold text-slate-900 truncate">
                                  {plan.title}
                                </h4>
                                {isApplied && (
                                  <span className="text-[9px] font-bold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full flex items-center space-x-0.5">
                                    <span>✓ Aplicada</span>
                                  </span>
                                )}
                                {isIgnored && (
                                  <span className="text-[9px] font-bold bg-slate-200 text-slate-600 px-2 py-0.5 rounded-full">
                                    Ignorado
                                  </span>
                                )}
                              </div>

                              <p className="text-xs text-slate-600 leading-relaxed font-normal">
                                {plan.description}
                              </p>

                              {/* Savings indicators */}
                              <div className="flex flex-wrap gap-4 text-[10px] font-bold text-slate-500 bg-slate-50 border border-slate-100 p-2 rounded-lg inline-flex">
                                <span>Ahorro Estimado: <strong className="text-emerald-600">S/ {plan.savingAmount}</strong></span>
                                <span className="text-slate-300">•</span>
                                <span>Mitigación: <strong className="text-emerald-600">-{plan.savingEmissions} kg CO₂</strong></span>
                              </div>

                              {/* Plan controls */}
                              {!isApplied && !isIgnored && (
                                <div className="flex items-center space-x-2 pt-2">
                                  <button
                                    onClick={() => handleApplyPlan(plan.id, plan.savingEmissions)}
                                    className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-[11px] rounded-lg shadow-xs transition-all active:scale-95"
                                  >
                                    Aplicar Estrategia
                                  </button>
                                  <button
                                    onClick={() => handleIgnorePlan(plan.id)}
                                    className="px-3 py-1.5 border border-slate-200 hover:bg-slate-50 text-slate-500 text-[11px] rounded-lg font-bold transition-all"
                                  >
                                    Omitir
                                  </button>
                                </div>
                              )}

                              {isApplied && (
                                <p className="text-[10px] text-emerald-700 font-bold flex items-center space-x-1.5 pt-1">
                                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                                  <span>Estrategia activa y emisiones descontadas del panel principal</span>
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Chatbot Column */}
                  <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4">
                    <div className="flex items-center space-x-2">
                      <MessageSquare className="w-4 h-4 text-emerald-500" />
                      <h4 className="text-xs font-bold text-slate-900">Soporte y Consultas EcoTrace IA</h4>
                    </div>

                    <p className="text-[11px] text-slate-500 leading-normal text-left">
                      Pregúntale a nuestro agente experto sobre regulaciones del MINAM, fórmulas de ahorro o dudas tributarias ecológicas.
                    </p>

                    {/* Chat log wrapper */}
                    <div className="border border-slate-100 rounded-2xl p-4 bg-slate-50 space-y-3">
                      <div className="h-44 overflow-y-auto space-y-2.5 pr-1 text-xs">
                        {chatReplies.map((msg, idx) => (
                          <div 
                            key={idx}
                            className={`p-2.5 rounded-xl max-w-[85%] leading-relaxed ${
                              msg.sender === 'ia'
                                ? 'bg-white border border-slate-200/60 text-slate-700 mr-auto text-left'
                                : 'bg-emerald-500 text-slate-950 font-bold ml-auto text-right'
                            }`}
                          >
                            {msg.text}
                          </div>
                        ))}

                        {isTyping && (
                          <div className="bg-white border border-slate-100 p-2 rounded-xl text-[10px] inline-flex items-center space-x-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce"></span>
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce [animation-delay:0.2s]"></span>
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce [animation-delay:0.4s]"></span>
                          </div>
                        )}
                      </div>

                      {/* Chips suggestions */}
                      <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-200/50">
                        {suggestions.map((s, idx) => (
                          <button
                            key={idx}
                            onClick={() => sendMessage(s)}
                            className="text-[9px] bg-white hover:bg-emerald-50 text-slate-600 hover:text-emerald-700 font-bold border border-slate-200 hover:border-emerald-200/50 rounded-full px-2 py-0.5 transition-all"
                          >
                            {s}
                          </button>
                        ))}
                      </div>

                      {/* Chat Input */}
                      <div className="flex items-center space-x-2 pt-2">
                        <input 
                          type="text" 
                          placeholder="Escribe tu consulta..."
                          value={chatPrompt}
                          onChange={(e) => setChatPrompt(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && sendMessage(chatPrompt)}
                          className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-emerald-500"
                        />
                        <button
                          onClick={() => sendMessage(chatPrompt)}
                          className="p-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl transition-all"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>

                </div>

              </div>
            )}

          </main>

        </div>
      )}

      {/* REPORT MODAL (MINAM CERTIFICATE) */}
      <ReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        carbonEmissions={carbonEmissions}
        transactions={transactions}
        userName={userName}
        companyName={companyName}
      />

    </div>
  );
}
