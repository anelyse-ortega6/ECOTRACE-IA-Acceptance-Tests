export interface Transaction {
  id: string;
  source: string;
  category: 'Combustible' | 'Electricidad' | 'Agua' | 'Residuos';
  date: string;
  amount: number;
  emissions: number; // in kg CO2
}

export interface ActionPlan {
  id: string;
  title: string;
  icon: 'route' | 'led' | 'water' | 'paper';
  description: string;
  savingAmount: number;
  savingEmissions: number; // in kg CO2
  status: 'pending' | 'applied' | 'ignored';
}

export interface LeadInfo {
  fullName: string;
  email: string;
  companyName: string;
}
