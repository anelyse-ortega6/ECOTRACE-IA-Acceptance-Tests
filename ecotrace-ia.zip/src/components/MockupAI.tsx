import React, { useState } from 'react';
import { Cpu, Send, CheckCircle, Info, Lightbulb, TrendingDown, RefreshCw, MessageSquare } from 'lucide-react';
import { ActionPlan } from '../types';

interface MockupAIProps {
  userName: string;
  actionPlans: ActionPlan[];
  onApplyPlan: (planId: string, savingEmissions: number) => void;
  onIgnorePlan: (planId: string) => void;
  onResetPlans: () => void;
}

export default function MockupAI({ userName, actionPlans, onApplyPlan, onIgnorePlan, onResetPlans }: MockupAIProps) {
  const [chatPrompt, setChatPrompt] = useState('');
  const [chatReplies, setChatReplies] = useState<Array<{ sender: 'user' | 'ia'; text: string }>>([
    { sender: 'ia', text: '¡Hola! He analizado tus facturas del último trimestre. Tu huella de carbono aumentó 12% debido a gastos en combustible.' }
  ]);
  const [isTyping, setIsTyping] = useState(false);

  // Quick suggestion prompts
  const suggestions = [
    '¿Cómo reduzco emisiones en logística?',
    'Planes para ahorrar luz en mi local',
    '¿Qué exige el MINAM para Mypes?'
  ];

  const handleSuggestionClick = (text: string) => {
    sendMessage(text);
  };

  const sendMessage = (text: string) => {
    if (!text.trim()) return;
    
    const newMessages = [...chatReplies, { sender: 'user', text }];
    setChatReplies(newMessages);
    setChatPrompt('');
    setIsTyping(true);

    // Simulate IA consultant response
    setTimeout(() => {
      let replyText = 'Entendido. Basado en los datos de tu Mype, te recomiendo optimizar el consumo de energía apagando equipos fuera de horario o implementando teletrabajo un día a la semana. Esto reduciría un estimado de 35 kg CO₂ mensuales.';
      if (text.toLowerCase().includes('logística') || text.toLowerCase().includes('combustible')) {
        replyText = 'Para logística, agrupar despachos por zonas puede reducir tus kilómetros recorridos en 18%. Esto se traduce en un ahorro de S/ 200 y una reducción de 50 kg de CO₂ en tu huella mensual.';
      } else if (text.toLowerCase().includes('luz') || text.toLowerCase().includes('iluminación')) {
        replyText = 'El cambio a luminarias LED de 15W genera un ahorro eléctrico de hasta el 60%. Para tu local, proyectamos un ahorro de S/ 95 mensuales y un retorno de inversión en menos de 4 meses.';
      } else if (text.toLowerCase().includes('minam')) {
        replyText = 'El MINAM promueve la plataforma "Huella de Carbono Perú". Las Mypes registradas obtienen un sello oficial de sostenibilidad que mejora su puntaje para licitaciones públicas y exportaciones.';
      }

      setChatReplies(prev => [...prev, { sender: 'ia', text: replyText }]);
      setIsTyping(false);
    }, 1500);
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-800 font-sans">
      {/* App Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100 bg-white sticky top-0 z-10 shadow-sm">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-slate-950 shadow-md">
            <Cpu className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <span className="font-bold text-xs block text-slate-900">Consultor IA Sostenible</span>
            <span className="text-[10px] text-emerald-600 font-medium">● Agente Activo</span>
          </div>
        </div>
        <button 
          onClick={onResetPlans}
          title="Reiniciar recomendaciones"
          className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Main Consultant View */}
      <div className="p-4 space-y-4 flex-1">
        {/* Welcome Salutation */}
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-100 shadow-sm text-slate-800 leading-tight">
          <p className="text-xs font-semibold text-emerald-950 mb-1">
            🌱 ¡Hola, {userName || "Emprendedor"}!
          </p>
          <p className="text-[11px] text-emerald-800">
            He preparado el plan de acción ambiental del mes para optimizar tus recursos y recortar gastos. ¡Empecemos a ahorrar!
          </p>
        </div>

        {/* Section Action Plans */}
        <div className="space-y-3">
          <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-1">
            Planes de Acción Recomendados
          </h4>

          {actionPlans.map((plan) => {
            const isApplied = plan.status === 'applied';
            const isIgnored = plan.status === 'ignored';

            return (
              <div 
                key={plan.id}
                className={`p-4 rounded-2xl border transition-all duration-300 ${
                  isApplied 
                    ? 'bg-emerald-50/40 border-emerald-200 opacity-90 shadow-sm' 
                    : isIgnored 
                    ? 'bg-slate-50 border-slate-200 opacity-60' 
                    : 'bg-white border-slate-100 shadow-sm hover:shadow-md'
                }`}
              >
                <div className="flex items-start space-x-3">
                  <div className={`p-2 rounded-xl shrink-0 ${
                    isApplied 
                      ? 'bg-emerald-100 text-emerald-700' 
                      : isIgnored 
                      ? 'bg-slate-200 text-slate-500' 
                      : 'bg-amber-50 text-amber-600 border border-amber-100'
                  }`}>
                    {plan.icon === 'route' ? (
                      <TrendingDown className="w-4 h-4" />
                    ) : (
                      <Lightbulb className="w-4 h-4" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-slate-900 truncate">
                        {plan.title}
                      </span>
                      {isApplied && (
                        <span className="text-[9px] font-bold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full flex items-center space-x-0.5">
                          <span>✓ Aplicado</span>
                        </span>
                      )}
                      {isIgnored && (
                        <span className="text-[9px] font-bold bg-slate-200 text-slate-600 px-2 py-0.5 rounded-full">
                          Ignorado
                        </span>
                      )}
                    </div>
                    
                    <p className="text-[11px] text-slate-600 leading-normal mb-2.5">
                      {plan.description}
                    </p>

                    <div className="flex items-center space-x-3 text-[10px] font-semibold text-slate-500 mb-3 bg-slate-50 px-2.5 py-1.5 rounded-lg border border-slate-100">
                      <div>
                        Ahorro: <span className="text-emerald-600 font-bold">S/ {plan.savingAmount}</span>
                      </div>
                      <div className="w-1 h-1 rounded-full bg-slate-300"></div>
                      <div>
                        Huella: <span className="text-emerald-600 font-bold">-{plan.savingEmissions}kg CO₂</span>
                      </div>
                    </div>

                    {!isApplied && !isIgnored && (
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => onApplyPlan(plan.id, plan.savingEmissions)}
                          className="flex-1 py-1.5 bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-bold text-[11px] rounded-lg shadow-sm transition-all text-center"
                        >
                          Aplicar
                        </button>
                        <button
                          onClick={() => onIgnorePlan(plan.id)}
                          className="px-3 py-1.5 border border-slate-200 hover:bg-slate-50 text-slate-500 hover:text-slate-700 font-medium text-[11px] rounded-lg transition-all text-center"
                        >
                          Ignorar
                        </button>
                      </div>
                    )}

                    {isApplied && (
                      <div className="text-[10px] text-emerald-700 font-medium flex items-center space-x-1">
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Emisiones reducidas en el Dashboard mensual</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* AI Chat Area Simulation */}
        <div className="pt-2 border-t border-slate-100">
          <div className="flex items-center space-x-1 mb-2 px-1">
            <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
            <h4 className="text-[11px] font-bold text-slate-900">Pregúntale a EcoTrace IA</h4>
          </div>

          <div className="bg-white rounded-2xl border border-slate-100 p-3 shadow-sm space-y-3">
            {/* Chat History View (max 3 messages shown) */}
            <div className="space-y-2 max-h-[140px] overflow-y-auto pr-1">
              {chatReplies.slice(-3).map((msg, idx) => (
                <div 
                  key={idx} 
                  className={`p-2 rounded-xl text-[10.5px] leading-relaxed max-w-[90%] ${
                    msg.sender === 'ia' 
                      ? 'bg-slate-50 text-slate-700 mr-auto' 
                      : 'bg-emerald-500 text-slate-950 font-medium ml-auto text-right'
                  }`}
                >
                  {msg.text}
                </div>
              ))}
              {isTyping && (
                <div className="bg-slate-50 text-slate-400 p-2 rounded-xl text-[10px] inline-flex items-center space-x-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce [animation-delay:0.2s]"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce [animation-delay:0.4s]"></span>
                </div>
              )}
            </div>

            {/* Suggestions list */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {suggestions.map((sug, i) => (
                <button
                  key={i}
                  onClick={() => handleSuggestionClick(sug)}
                  className="text-[9px] text-slate-600 hover:text-emerald-700 bg-slate-100 hover:bg-emerald-50 border border-slate-200/60 rounded-full px-2 py-0.5 transition-all text-left"
                >
                  {sug}
                </button>
              ))}
            </div>

            {/* Input field */}
            <div className="flex items-center space-x-1 bg-slate-50 rounded-xl px-2.5 py-1.5 border border-slate-100">
              <input
                type="text"
                placeholder="Escribe tu consulta ambiental..."
                value={chatPrompt}
                onChange={(e) => setChatPrompt(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendMessage(chatPrompt)}
                className="flex-1 bg-transparent text-[11px] focus:outline-none placeholder-slate-400 text-slate-800"
              />
              <button
                onClick={() => sendMessage(chatPrompt)}
                className="p-1 bg-emerald-500 text-slate-950 rounded-lg hover:bg-emerald-400 transition-colors"
              >
                <Send className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
