import React from 'react';
import { Wifi, Battery, Signal } from 'lucide-react';

interface PhoneShellProps {
  title: string;
  children: React.ReactNode;
  phoneColor?: string;
}

export default function PhoneShell({ title, children, phoneColor = 'border-slate-800 bg-slate-900' }: PhoneShellProps) {
  // Get current hour and minute for the status bar
  const now = new Date();
  const timeString = now.toLocaleTimeString('es-PE', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });

  return (
    <div className="relative mx-auto w-full max-w-[360px] h-[720px] rounded-[48px] border-[12px] border-slate-900 bg-slate-950 shadow-2xl overflow-hidden transition-all duration-300 hover:shadow-emerald-500/10 hover:border-slate-800 flex flex-col select-none">
      {/* Notch / Dynamic Island */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-900 rounded-b-2xl z-50 flex items-center justify-center">
        <div className="w-3 h-3 rounded-full bg-slate-950 mr-1 border border-slate-800"></div>
        <div className="w-12 h-1 bg-slate-950 rounded-full"></div>
      </div>

      {/* Screen Container */}
      <div className="relative w-full h-full bg-slate-50 flex flex-col overflow-hidden text-slate-800 text-sm">
        
        {/* Status Bar */}
        <div className="flex justify-between items-center px-6 pt-3 pb-2 text-slate-900 font-medium text-xs z-40 bg-slate-50">
          <span>{timeString}</span>
          <div className="flex items-center space-x-1">
            <Signal className="w-3.5 h-3.5 text-slate-900" />
            <Wifi className="w-3.5 h-3.5 text-slate-900" />
            <Battery className="w-4 h-4 text-slate-900" />
          </div>
        </div>

        {/* Content View - Scrollable */}
        <div className="flex-1 overflow-y-auto flex flex-col pb-8">
          {children}
        </div>

        {/* Home Indicator Line */}
        <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-32 h-1 bg-slate-400 rounded-full z-40"></div>
      </div>
    </div>
  );
}
