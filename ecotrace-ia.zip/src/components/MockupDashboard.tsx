import React from 'react';
import { Fuel, Zap, Droplet, Trash2, Calendar, FileText, TrendingDown, ArrowUpRight, TrendingUp } from 'lucide-react';
import { Transaction } from '../types';

interface MockupDashboardProps {
  carbonEmissions: number;
  transactions: Transaction[];
  onGenerateReport: () => void;
  userName: string;
}

export default function MockupDashboard({ carbonEmissions, transactions, onGenerateReport, userName }: MockupDashboardProps) {
  // We can calculate dynamic heights for the bars based on emissions
  // Ene: 240, Feb: 380, Mar: 310, Abr: current emissions!
  const baseMonths = [
    { name: 'Ene', value: 240, color: 'bg-emerald-300' },
    { name: 'Feb', value: 380, color: 'bg-emerald-400' },
    { name: 'Mar', value: 310, color: 'bg-emerald-500' },
    { name: 'Abr', value: Math.round(carbonEmissions), color: 'bg-emerald-600 shadow-[0_0_8px_rgba(16,185,129,0.5)]' }
  ];

  const maxVal = Math.max(...baseMonths.map(m => m.value));

  // Category Icon helper
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Combustible':
        return <Fuel className="w-4 h-4 text-amber-500" />;
      case 'Electricidad':
        return <Zap className="w-4 h-4 text-emerald-500" />;
      case 'Agua':
        return <Droplet className="w-4 h-4 text-blue-500" />;
      case 'Residuos':
        return <Trash2 className="w-4 h-4 text-slate-500" />;
      default:
        return <FileText className="w-4 h-4 text-slate-500" />;
    }
  };

  const getCategoryBg = (category: string) => {
    switch (category) {
      case 'Combustible': return 'bg-amber-50 border border-amber-100';
      case 'Electricidad': return 'bg-emerald-50 border border-emerald-100';
      case 'Agua': return 'bg-blue-50 border border-blue-100';
      case 'Residuos': return 'bg-slate-50 border border-slate-100';
      default: return 'bg-slate-50';
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-800 font-sans">
      {/* App Header */}
      <div className="px-4 py-3 border-b border-slate-100 bg-white sticky top-0 z-10 shadow-sm flex items-center justify-between">
        <div>
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">MYPE: {userName || "EcoTrace Demo"}</span>
          <h2 className="font-bold text-sm text-slate-900 leading-tight">Panel de Emisiones</h2>
        </div>
        <div className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2.5 py-1 rounded-full border border-emerald-100 flex items-center space-x-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>Sincronizado</span>
        </div>
      </div>

      {/* Main Container */}
      <div className="p-4 space-y-4 flex-1">
        
        {/* Hero Card - Huella de Carbono Actual */}
        <div className="bg-gradient-to-br from-emerald-600 to-teal-700 rounded-3xl p-5 text-white shadow-lg relative overflow-hidden">
          {/* Ambient graphic rings */}
          <div className="absolute -right-6 -bottom-6 w-28 h-28 rounded-full border-4 border-white/5 pointer-events-none"></div>
          <div className="absolute right-6 -top-6 w-20 h-20 rounded-full border-4 border-white/5 pointer-events-none"></div>

          <div className="relative z-10">
            <span className="text-[10px] uppercase font-bold text-emerald-100/90 tracking-widest block mb-1">
              Huella de Carbono Actual
            </span>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-extrabold tracking-tight">
                {carbonEmissions.toLocaleString('es-PE')}
              </span>
              <span className="text-sm font-bold text-emerald-100">kg CO₂eq</span>
            </div>
            
            <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-emerald-50">
              <span className="flex items-center space-x-1">
                {carbonEmissions < 450 ? (
                  <TrendingDown className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                ) : (
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                )}
                <span>
                  {carbonEmissions < 450 
                    ? `¡Ahorraste ${Math.round(450 - carbonEmissions)} kg este mes!` 
                    : "Límite mensual proyectado: 500kg"}
                </span>
              </span>
              <span className="font-bold underline text-white cursor-pointer hover:text-emerald-100 transition-colors" onClick={onGenerateReport}>
                Ver detalles
              </span>
            </div>
          </div>
        </div>

        {/* Chart Section */}
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-bold text-slate-900">Histórico de Emisiones</h4>
            <span className="text-[10px] text-slate-500 font-semibold">Mensual (2026)</span>
          </div>

          {/* Bar Chart Container */}
          <div className="h-28 flex items-end justify-between px-3 pt-3 border-b border-slate-100">
            {baseMonths.map((month, index) => {
              // Calculate height percentage
              const heightPct = maxVal > 0 ? (month.value / maxVal) * 100 : 0;
              return (
                <div key={index} className="flex flex-col items-center flex-1 group">
                  {/* Tooltip bar indicator */}
                  <span className="text-[9px] font-bold text-slate-600 mb-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                    {month.value}
                  </span>
                  {/* Visual Bar */}
                  <div 
                    style={{ height: `${Math.max(heightPct, 15)}%` }}
                    className={`w-10 rounded-t-lg ${month.color} transition-all duration-500 ease-out`}
                  ></div>
                  {/* Month name */}
                  <span className="text-[10px] font-bold text-slate-500 mt-1.5">{month.name}</span>
                </div>
              );
            })}
          </div>
          <div className="flex justify-between items-center text-[10px] text-slate-400 mt-2 px-1">
            <span>Métrica: kg CO₂ / mes</span>
            <span className="text-emerald-600 font-semibold flex items-center space-x-0.5">
              <span>● Periodo Actual: Abr</span>
            </span>
          </div>
        </div>

        {/* Transactions Section */}
        <div className="space-y-2">
          <div className="flex items-center justify-between px-1">
            <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Consumos Recientes
            </h4>
            <span className="text-[10px] text-slate-500">Total: {transactions.length} registros</span>
          </div>

          <div className="space-y-2 max-h-[190px] overflow-y-auto pr-1">
            {transactions.map((tx) => (
              <div 
                key={tx.id} 
                className="bg-white p-3 rounded-xl border border-slate-100 shadow-sm flex items-center justify-between hover:border-slate-200 transition-all"
              >
                <div className="flex items-center space-x-2.5">
                  <div className={`p-2 rounded-lg ${getCategoryBg(tx.category)}`}>
                    {getCategoryIcon(tx.category)}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block leading-tight">
                      {tx.source}
                    </span>
                    <span className="text-[9.5px] text-slate-500 flex items-center space-x-1 mt-0.5">
                      <Calendar className="w-2.5 h-2.5" />
                      <span>{tx.date}</span>
                      <span>•</span>
                      <span className="font-semibold text-slate-600">{tx.category}</span>
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-bold text-slate-900 block">
                    S/ {tx.amount.toFixed(2)}
                  </span>
                  <span className="text-[9.5px] font-bold text-amber-600 bg-amber-50 border border-amber-100/60 rounded px-1 py-0.2 ml-auto inline-block mt-0.5">
                    +{tx.emissions} kg CO₂
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sticky Bottom Footer button */}
      <div className="p-4 border-t border-slate-100 bg-white sticky bottom-0 z-10 shadow-md">
        <button
          onClick={onGenerateReport}
          className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-md hover:shadow-emerald-500/10 active:scale-98 transition-all flex items-center justify-center space-x-2"
        >
          <FileText className="w-4 h-4" />
          <span>Generar Reporte MINAM (PDF)</span>
        </button>
      </div>
    </div>
  );
}
