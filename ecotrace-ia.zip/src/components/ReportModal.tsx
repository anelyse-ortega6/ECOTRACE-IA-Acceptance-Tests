import React, { useRef } from 'react';
import { X, Download, ShieldCheck, Check, Printer, FileCheck } from 'lucide-react';
import { Transaction } from '../types';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  carbonEmissions: number;
  transactions: Transaction[];
  userName: string;
  companyName: string;
}

export default function ReportModal({ isOpen, onClose, carbonEmissions, transactions, userName, companyName }: ReportModalProps) {
  if (!isOpen) return null;

  const reportId = "ET-2026-MINAM-4819";
  const dateStr = new Date().toLocaleDateString('es-PE', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  });

  // Calculate percentage of emissions per category
  const categories = ['Combustible', 'Electricidad', 'Agua', 'Residuos'] as const;
  const emissionsByCategory = categories.map(cat => {
    const total = transactions
      .filter(t => t.category === cat)
      .reduce((sum, t) => sum + t.emissions, 0);
    return { category: cat, value: total };
  });

  // Total sum
  const sumOfCalculated = emissionsByCategory.reduce((sum, c) => sum + c.value, 0);

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden border border-slate-100 flex flex-col my-8 animate-fade-in">
        
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Documento Oficial Generado</span>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Certificate Body Container */}
        <div className="p-8 overflow-y-auto max-h-[70vh] space-y-6">
          
          {/* Official Document Layout */}
          <div className="border-[3px] border-double border-slate-300 p-6 rounded-2xl bg-white relative">
            
            {/* Watermark Logo Accent */}
            <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none">
              <img 
                src="https://i.postimg.cc/y6Tv4Cz3/logo-Eco-Trace1.png" 
                alt="Watermark Logo" 
                className="w-80 object-contain"
              />
            </div>

            {/* Document Header */}
            <div className="flex flex-col sm:flex-row items-center justify-between border-b border-slate-200 pb-4 mb-6">
              <div className="text-center sm:text-left mb-4 sm:mb-0">
                <p className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Plataforma Oficial</p>
                <div className="flex items-center justify-center sm:justify-start space-x-2 mt-1">
                  <img 
                    src="https://i.postimg.cc/y6Tv4Cz3/logo-Eco-Trace1.png" 
                    alt="EcoTrace Logo" 
                    className="h-7 object-contain"
                  />
                  <span className="font-extrabold text-sm text-emerald-600">EcoTrace IA</span>
                </div>
              </div>

              <div className="text-center sm:text-right">
                <p className="text-[9px] font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded-full inline-block border border-slate-200">
                  HUELLA DE CARBONO PERÚ - MINAM
                </p>
                <p className="text-[10px] text-slate-400 font-mono mt-1">Doc ID: {reportId}</p>
              </div>
            </div>

            {/* Certificate Title */}
            <div className="text-center space-y-2 mb-8">
              <p className="text-xs font-bold text-emerald-600 uppercase tracking-widest">Certificado de Declaración de Emisiones</p>
              <h3 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight">
                REPORTE DE HUELLA DE CARBONO
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                De conformidad con las directrices del Ministerio del Ambiente (MINAM) y el estándar internacional GHG Protocol.
              </p>
            </div>

            {/* Declarant Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100 text-xs mb-6">
              <div>
                <p className="text-slate-400 font-semibold uppercase text-[9px] tracking-wider">Razón Social de la Mype</p>
                <p className="font-bold text-slate-800 text-sm mt-0.5">{companyName || "EcoTrace S.A.C."}</p>
              </div>
              <div>
                <p className="text-slate-400 font-semibold uppercase text-[9px] tracking-wider">Representante de Sostenibilidad</p>
                <p className="font-bold text-slate-800 text-sm mt-0.5">{userName || "Julio Ramos"}</p>
              </div>
              <div>
                <p className="text-slate-400 font-semibold uppercase text-[9px] tracking-wider">Periodo Auditado por IA</p>
                <p className="font-bold text-slate-800 mt-0.5">Abril - Junio 2026</p>
              </div>
              <div>
                <p className="text-slate-400 font-semibold uppercase text-[9px] tracking-wider">Fecha de Emisión del Reporte</p>
                <p className="font-bold text-slate-800 mt-0.5">{dateStr}</p>
              </div>
            </div>

            {/* Core Calculations */}
            <div className="border border-slate-200 rounded-xl overflow-hidden mb-6">
              <div className="bg-slate-800 text-white px-4 py-2.5 flex justify-between items-center text-xs">
                <span className="font-bold">Fuentes de Emisión Declaradas</span>
                <span className="font-mono text-slate-300">GHG Protocol Scope 1 & 2</span>
              </div>
              
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[10px] text-slate-400 font-bold uppercase">
                    <th className="px-4 py-2">Categoría de Recurso</th>
                    <th className="px-4 py-2">Fuente</th>
                    <th className="px-4 py-2 text-right">Emisiones Estimadas</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {emissionsByCategory.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50">
                      <td className="px-4 py-2.5 font-bold text-slate-800">{item.category}</td>
                      <td className="px-4 py-2.5 text-slate-500">
                        {item.category === 'Combustible' && 'Consumo Gasolina / Logística de distribución'}
                        {item.category === 'Electricidad' && 'Consumo eléctrico de oficinas administrativas'}
                        {item.category === 'Agua' && 'Suministro de agua potable operacional'}
                        {item.category === 'Residuos' && 'Residuos sólidos orgánicos e inorgánicos'}
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono font-bold text-slate-700">
                        {item.value > 0 ? `${item.value} kg CO₂eq` : '0 kg CO₂eq'}
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-emerald-50/30 font-bold">
                    <td className="px-4 py-3 text-emerald-800">TOTAL DECLARADO</td>
                    <td className="px-4 py-3"></td>
                    <td className="px-4 py-3 text-right font-mono text-emerald-700 text-sm">
                      {carbonEmissions} kg CO₂eq
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Footer with Signatures and QR */}
            <div className="flex flex-col sm:flex-row items-center justify-between pt-6 border-t border-slate-200 mt-6 gap-6">
              {/* Security Validation Code and QR */}
              <div className="flex items-center space-x-3 text-left">
                {/* Simulated QR Code SVG */}
                <div className="w-16 h-16 bg-slate-100 border border-slate-200 p-1 rounded-md flex flex-col justify-between shrink-0">
                  <div className="grid grid-cols-4 gap-1 h-full">
                    <div className="bg-slate-800 rounded-xs"></div>
                    <div className="bg-slate-800 rounded-xs"></div>
                    <div className="bg-slate-100"></div>
                    <div className="bg-slate-800 rounded-xs"></div>
                    <div className="bg-slate-100"></div>
                    <div className="bg-slate-800 rounded-xs"></div>
                    <div className="bg-slate-800 rounded-xs"></div>
                    <div className="bg-slate-100"></div>
                    <div className="bg-slate-800 rounded-xs"></div>
                    <div className="bg-slate-100"></div>
                    <div className="bg-slate-800 rounded-xs"></div>
                    <div className="bg-slate-800 rounded-xs"></div>
                    <div className="bg-slate-800 rounded-xs"></div>
                    <div className="bg-slate-800 rounded-xs"></div>
                    <div className="bg-slate-100"></div>
                    <div className="bg-slate-800 rounded-xs"></div>
                  </div>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-800 flex items-center space-x-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Validación Digital MINAM</span>
                  </p>
                  <p className="text-[9px] text-slate-400 mt-0.5 max-w-[160px] leading-tight">
                    Certificación automatizada por EcoTrace IA. Firmado digitalmente y listo para su registro directo en el portal del Ministerio.
                  </p>
                </div>
              </div>

              {/* Digital Signatures */}
              <div className="flex space-x-6 text-center text-[10px]">
                <div className="flex flex-col items-center">
                  <div className="h-8 flex items-end justify-center">
                    <span className="font-mono italic text-emerald-600 text-xs font-bold leading-none">EcoTrace IA Agent</span>
                  </div>
                  <div className="w-24 border-t border-slate-300 mt-1"></div>
                  <p className="font-bold text-slate-700 mt-1">Soporte EcoTrace IA</p>
                  <p className="text-slate-400">Verificador Tecnológico</p>
                </div>

                <div className="flex flex-col items-center">
                  <div className="h-8 flex items-end justify-center">
                    <span className="font-mono italic text-blue-800 text-[11px] font-semibold leading-none">{userName || "Representante"}</span>
                  </div>
                  <div className="w-24 border-t border-slate-300 mt-1"></div>
                  <p className="font-bold text-slate-700 mt-1">{userName || "Declarante Mype"}</p>
                  <p className="text-slate-400">Representante Legal</p>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Action Controls Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[11px] text-slate-500 text-center sm:text-left">
            💡 EcoTrace IA envía directamente los datos al sistema nacional del MINAM para ahorrarte multas.
          </p>
          <div className="flex space-x-2 w-full sm:w-auto">
            <button
              onClick={() => {
                alert("¡Descarga simulada! Se ha iniciado la descarga del reporte '" + reportId + ".pdf'.");
              }}
              className="flex-1 sm:flex-initial flex items-center justify-center space-x-1.5 px-4 py-2 border border-slate-200 hover:bg-slate-100 rounded-xl text-slate-700 font-semibold text-xs transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Descargar PDF</span>
            </button>
            <button
              onClick={() => {
                alert("¡Felicidades! Los datos han sido presentados formalmente al MINAM con el ID " + reportId + ". El sello oficial ha sido otorgado.");
              }}
              className="flex-1 sm:flex-initial flex items-center justify-center space-x-1.5 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs transition-colors shadow-sm"
            >
              <FileCheck className="w-4 h-4" />
              <span>Presentar a MINAM</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
