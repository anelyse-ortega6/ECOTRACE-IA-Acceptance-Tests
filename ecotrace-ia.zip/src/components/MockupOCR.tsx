import React, { useState, useEffect } from 'react';
import { ChevronLeft, Camera, CheckCircle2, RefreshCw, Landmark, Fuel, HelpCircle } from 'lucide-react';
import { Transaction } from '../types';

interface MockupOCRProps {
  onAddTransaction: (ruc: string, amount: number, category: 'Combustible' | 'Electricidad' | 'Agua' | 'Residuos') => void;
  userName: string;
}

export default function MockupOCR({ onAddTransaction, userName }: MockupOCRProps) {
  const [scanState, setScanState] = useState<'idle' | 'scanning' | 'scanned'>('idle');
  const [ruc, setRuc] = useState('20123456789');
  const [amount, setAmount] = useState('150.00');
  const [category, setCategory] = useState<'Combustible' | 'Electricidad' | 'Agua' | 'Residuos'>('Combustible');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Auto scan simulation
  const startScanning = () => {
    setScanState('scanning');
    setSaveSuccess(false);
  };

  useEffect(() => {
    if (scanState === 'scanning') {
      const timer = setTimeout(() => {
        setScanState('scanned');
      }, 2200);
      return () => clearTimeout(timer);
    }
  }, [scanState]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (scanState !== 'scanned') return;

    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) return;

    onAddTransaction(ruc, numericAmount, category);
    setSaveSuccess(true);
    setScanState('idle');

    // Toast auto-hide
    setTimeout(() => {
      setSaveSuccess(false);
    }, 4000);
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 text-white font-sans">
      {/* App Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-10">
        <button className="p-1 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <span className="font-semibold text-sm tracking-wide">Escanear Factura</span>
        <div className="w-7 h-7 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
          <Camera className="w-3.5 h-3.5 text-emerald-400" />
        </div>
      </div>

      {/* Main Scanner Viewport Area */}
      <div className="relative flex-1 bg-black flex flex-col items-center justify-center p-4 h-[260px] min-h-[220px]">
        {scanState === 'idle' && (
          <div className="text-center p-6 flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-slate-800/80 border-2 border-dashed border-emerald-500/40 flex items-center justify-center mb-4 animate-pulse-ring">
              <Camera className="w-7 h-7 text-emerald-400" />
            </div>
            <p className="text-xs text-slate-300 font-medium mb-1">Cámara Lista</p>
            <p className="text-[11px] text-slate-500 max-w-[200px] mb-4">
              Coloca el recibo o factura dentro del recuadro
            </p>
            <button
              onClick={startScanning}
              className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-full transition-all duration-200 shadow-lg shadow-emerald-500/20 active:scale-95"
            >
              Simular Captura IA
            </button>
          </div>
        )}

        {scanState === 'scanning' && (
          <div className="relative w-full h-full max-w-[280px] rounded-lg overflow-hidden border border-emerald-500/50 bg-slate-950/80 flex items-center justify-center">
            {/* Camera Guides */}
            <div className="absolute top-3 left-3 w-4 h-4 border-t-2 border-l-2 border-emerald-400"></div>
            <div className="absolute top-3 right-3 w-4 h-4 border-t-2 border-r-2 border-emerald-400"></div>
            <div className="absolute bottom-3 left-3 w-4 h-4 border-b-2 border-l-2 border-emerald-400"></div>
            <div className="absolute bottom-3 right-3 w-4 h-4 border-b-2 border-r-2 border-emerald-400"></div>

            {/* Simulating Receipt UI */}
            <div className="text-left font-mono text-[9px] text-slate-400 leading-normal p-4 opacity-40 select-none">
              <p className="text-center font-bold text-emerald-400 text-[10px]">REPSOL PERÚ S.A.C.</p>
              <p className="text-center">RUC: 20123456789</p>
              <p className="mt-2">F/ SIM-998811</p>
              <p>FECHA: 27/06/2026</p>
              <p className="border-t border-dashed border-slate-700 my-1"></p>
              <p>CANT  DETALLE        TOTAL</p>
              <p>4.5G  DIESEL D-B5     S/ 150.00</p>
              <p className="border-b border-dashed border-slate-700 my-1"></p>
              <p className="text-right font-bold text-white">TOTAL: S/ 150.00</p>
            </div>

            {/* Scanning Laser bar */}
            <div className="absolute left-0 right-0 h-0.5 bg-emerald-400 shadow-[0_0_12px_#10B981] animate-scan-laser z-10"></div>
            
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-slate-900/90 px-3 py-1 rounded-full text-[10px] text-emerald-400 font-semibold tracking-wide border border-emerald-500/20 flex items-center space-x-1.5 shadow-md">
              <RefreshCw className="w-2.5 h-2.5 animate-spin" />
              <span>Extrayendo con OCR...</span>
            </div>
          </div>
        )}

        {scanState === 'scanned' && (
          <div className="relative w-full h-full max-w-[280px] rounded-lg overflow-hidden border border-emerald-500 bg-slate-950/90 flex flex-col justify-between p-4 animate-fade-in">
            <div className="flex items-center justify-between border-b border-slate-800/60 pb-2">
              <span className="text-[10px] uppercase font-mono tracking-wider text-emerald-400 font-bold">OCR Lectura Exitosa</span>
              <span className="text-[9px] text-slate-400">Score IA: 99.4%</span>
            </div>
            
            <div className="my-auto flex items-center justify-center space-x-3 py-2">
              <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div className="text-left">
                <p className="text-[11px] text-slate-400 leading-tight">Mype: {userName || "EcoTrace Demo"}</p>
                <p className="text-xs font-bold text-white">Factura de Combustible</p>
                <p className="text-[10px] text-slate-400">Monto: S/ 150.00 | RUC: 20123456789</p>
              </div>
            </div>

            <div className="flex justify-center">
              <button 
                onClick={startScanning} 
                className="flex items-center space-x-1 text-[10px] text-slate-400 hover:text-emerald-400 transition-colors"
              >
                <RefreshCw className="w-2.5 h-2.5" />
                <span>Escanear de nuevo</span>
              </button>
            </div>
          </div>
        )}

        {/* Success Banner */}
        {saveSuccess && (
          <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center p-6 text-center z-20">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center mb-2">
              <CheckCircle2 className="w-7 h-7 text-emerald-400" />
            </div>
            <h4 className="text-sm font-bold text-white mb-1">¡Datos Guardados!</h4>
            <p className="text-[11px] text-slate-400 max-w-[180px] leading-tight mb-3">
              Monto e indicador de Huella de Carbono actualizados en el Dashboard.
            </p>
            <div className="inline-flex items-center space-x-1 text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
              <span>+45 kg CO₂ en Dashboard</span>
            </div>
          </div>
        )}
      </div>

      {/* Panel Inferior - Bottom Sheet */}
      <form onSubmit={handleSave} className="bg-white text-slate-800 rounded-t-[28px] px-5 pt-4 pb-6 shadow-2xl flex-1 flex flex-col justify-between">
        <div>
          {/* Header indicator bar */}
          <div className="w-12 h-1 bg-slate-200 rounded-full mx-auto mb-4"></div>
          
          <div className="mb-4">
            <h3 className="text-sm font-bold text-slate-900">Datos Extraídos por IA</h3>
            <p className="text-[10.5px] text-slate-500">
              Valida la información leída antes de registrar la emisión.
            </p>
          </div>

          <div className="space-y-3">
            {/* RUC Input */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">RUC de Emisor</label>
              <div className="relative">
                <input
                  type="text"
                  value={ruc}
                  onChange={(e) => setRuc(e.target.value)}
                  disabled={scanState !== 'scanned'}
                  className={`w-full text-xs font-mono px-3 py-2 rounded-lg border focus:outline-none transition-all ${
                    scanState !== 'scanned'
                      ? 'bg-slate-50 border-slate-200 text-slate-400 cursor-not-allowed'
                      : 'border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10'
                  }`}
                  placeholder="Ej. 20123456789"
                  required
                />
                <div className="absolute right-3 top-2.5">
                  <Landmark className={`w-3.5 h-3.5 ${scanState === 'scanned' ? 'text-emerald-500' : 'text-slate-300'}`} />
                </div>
              </div>
            </div>

            {/* Categoría Input */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Categoría</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                disabled={scanState !== 'scanned'}
                className={`w-full text-xs px-3 py-2 rounded-lg border focus:outline-none transition-all ${
                  scanState !== 'scanned'
                    ? 'bg-slate-50 border-slate-200 text-slate-400 cursor-not-allowed'
                    : 'border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10'
                }`}
              >
                <option value="Combustible">🔥 Combustible (Gasolina/Diesel)</option>
                <option value="Electricidad">⚡ Electricidad (KWh)</option>
                <option value="Agua">💧 Consumo de Agua (m³)</option>
                <option value="Residuos">♻️ Generación de Residuos</option>
              </select>
            </div>

            {/* Monto Total Input */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Monto Total (S/)</label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-medium">S/</span>
                <input
                  type="text"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  disabled={scanState !== 'scanned'}
                  className={`w-full text-xs px-8 py-2 rounded-lg border focus:outline-none transition-all ${
                    scanState !== 'scanned'
                      ? 'bg-slate-50 border-slate-200 text-slate-400 cursor-not-allowed'
                      : 'border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10 font-bold'
                  }`}
                  placeholder="0.00"
                  required
                />
                <div className="absolute right-3 top-2.5">
                  <span className={`text-[10px] font-bold ${scanState === 'scanned' ? 'text-emerald-500' : 'text-slate-300'}`}>PEN</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Validate and Save Button */}
        <div className="mt-4 pt-2 border-t border-slate-100">
          <button
            type="submit"
            disabled={scanState !== 'scanned'}
            className={`w-full py-2.5 rounded-xl font-bold text-xs text-center transition-all shadow-md flex items-center justify-center space-x-2 ${
              scanState === 'scanned'
                ? 'bg-emerald-500 text-slate-950 hover:bg-emerald-400 hover:shadow-emerald-500/10 cursor-pointer active:scale-98'
                : 'bg-slate-100 text-slate-400 cursor-not-allowed'
            }`}
          >
            <span>Validar y Guardar</span>
          </button>
          
          {scanState !== 'scanned' && (
            <p className="text-[10px] text-center text-slate-400 mt-2">
              ⚠️ Haz click arriba en <strong className="text-slate-500">"Simular Captura IA"</strong> primero para leer los datos.
            </p>
          )}
        </div>
      </form>
    </div>
  );
}
